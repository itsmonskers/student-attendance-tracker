<?php

namespace App\Controllers;

use App\Models\StudentModel;
use App\Models\AttendanceModel;
use CodeIgniter\I18n\Time;

class Attendance extends BaseController
{
    protected $studentModel;
    protected $attendanceModel;

    public function __construct()
    {
        $this->studentModel = new StudentModel();
        $this->attendanceModel = new AttendanceModel();
    }

    public function index()
    {
        // Get all attendance records with student names
        $query = $this->attendanceModel->select('attendance.*, students.name as student_name')
                                    ->join('students', 'students.id = attendance.student_id')
                                    ->orderBy('attendance.date', 'DESC');
        
        $data = [
            'title' => 'Attendance Records',
            'attendance' => $query->findAll()
        ];

        return view('attendance/index', $data);
    }

    public function daily()
    {
        // Get selected date or use today's date
        $date = $this->request->getGet('date') ?? date('Y-m-d');
        
        // Get all students
        $students = $this->studentModel->findAll();
        
        // Get attendance records for the selected date
        $attendanceRecords = $this->attendanceModel->where('date', $date)->findAll();
        
        // Format attendance records by student ID for easy access
        $records = [];
        foreach ($attendanceRecords as $record) {
            $records[$record['student_id']] = $record;
        }
        
        $data = [
            'title' => 'Daily Attendance',
            'date' => $date,
            'students' => $students,
            'records' => $records
        ];

        return view('attendance/daily', $data);
    }

    public function save()
    {
        // Validate input
        $rules = [
            'date' => 'required|valid_date',
            'students' => 'required|array',
            'status' => 'required|array'
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()
                           ->with('error', 'Please check the form for errors.');
        }

        $date = $this->request->getPost('date');
        $students = $this->request->getPost('students');
        $statuses = $this->request->getPost('status');
        
        // Begin transaction
        $this->attendanceModel->db->transBegin();
        
        try {
            // Save attendance for each student
            foreach ($students as $index => $studentId) {
                $status = $statuses[$index] ?? 'present'; // Default to present if not specified
                
                // Check if record already exists for this date and student
                $existingRecord = $this->attendanceModel->where('student_id', $studentId)
                                                      ->where('date', $date)
                                                      ->first();
                
                if ($existingRecord) {
                    // Update existing record
                    $this->attendanceModel->update($existingRecord['id'], [
                        'status' => $status
                    ]);
                } else {
                    // Add new record
                    $this->attendanceModel->save([
                        'student_id' => $studentId,
                        'date' => $date,
                        'status' => $status
                    ]);
                }
            }
            
            $this->attendanceModel->db->transCommit();
            session()->setFlashdata('success', 'Attendance saved successfully.');
        } catch (\Exception $e) {
            $this->attendanceModel->db->transRollback();
            session()->setFlashdata('error', 'An error occurred while saving attendance: ' . $e->getMessage());
        }
        
        return redirect()->to('/attendance/daily?date=' . $date);
    }

    public function report()
    {
        // Get filter parameters
        $startDate = $this->request->getGet('start_date') ?? date('Y-m-d', strtotime('-30 days'));
        $endDate = $this->request->getGet('end_date') ?? date('Y-m-d');
        $studentId = $this->request->getGet('student_id') ?? '';
        
        // Get all students for the dropdown
        $students = $this->studentModel->findAll();
        
        // Build query
        $query = $this->attendanceModel->select('attendance.*, students.name as student_name')
                                    ->join('students', 'students.id = attendance.student_id')
                                    ->where('attendance.date >=', $startDate)
                                    ->where('attendance.date <=', $endDate)
                                    ->orderBy('attendance.date', 'DESC');
        
        // Add student filter if selected
        if (!empty($studentId)) {
            $query->where('attendance.student_id', $studentId);
        }
        
        $data = [
            'title' => 'Attendance Report',
            'report' => $query->findAll(),
            'startDate' => $startDate,
            'endDate' => $endDate,
            'studentId' => $studentId,
            'students' => $students
        ];

        return view('attendance/report', $data);
    }
}