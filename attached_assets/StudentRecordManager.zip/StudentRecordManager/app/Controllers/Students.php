<?php

namespace App\Controllers;

use App\Models\StudentModel;
use App\Models\AttendanceModel;
use CodeIgniter\Exceptions\PageNotFoundException;

class Students extends BaseController
{
    protected $studentModel;
    protected $attendanceModel;

    public function __construct()
    {
        $this->studentModel = new StudentModel();
        $this->attendanceModel = new AttendanceModel();
    }

    public function index()
    {
        $data = [
            'title' => 'Students',
            'students' => $this->studentModel->findAll()
        ];

        return view('students/index', $data);
    }

    public function new()
    {
        $data = [
            'title' => 'Add New Student'
        ];

        return view('students/create', $data);
    }

    public function create()
    {
        // Validate input
        $rules = $this->studentModel->getValidationRules();
        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        // Add student to database
        $this->studentModel->save([
            'name' => $this->request->getPost('name'),
            'age' => $this->request->getPost('age'),
            'course' => $this->request->getPost('course'),
            'grade' => $this->request->getPost('grade')
        ]);

        // Flash message
        session()->setFlashdata('success', 'Student successfully added.');

        return redirect()->to('/students');
    }

    public function edit($id = null)
    {
        if ($id === null) {
            throw new PageNotFoundException('Student ID not provided');
        }

        $student = $this->studentModel->find($id);
        if (!$student) {
            throw new PageNotFoundException('Student not found');
        }

        $data = [
            'title' => 'Edit Student',
            'student' => $student
        ];

        return view('students/edit', $data);
    }

    public function update($id = null)
    {
        if ($id === null) {
            throw new PageNotFoundException('Student ID not provided');
        }

        // Validate input
        $rules = $this->studentModel->getValidationRules();
        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        // Update student in database
        $this->studentModel->update($id, [
            'name' => $this->request->getPost('name'),
            'age' => $this->request->getPost('age'),
            'course' => $this->request->getPost('course'),
            'grade' => $this->request->getPost('grade')
        ]);

        // Flash message
        session()->setFlashdata('success', 'Student successfully updated.');

        return redirect()->to('/students');
    }

    public function delete($id = null)
    {
        if ($id === null) {
            throw new PageNotFoundException('Student ID not provided');
        }

        // Delete student from database
        $this->studentModel->delete($id);

        // Flash message
        session()->setFlashdata('success', 'Student successfully deleted.');

        return redirect()->to('/students');
    }

    public function show($id = null)
    {
        if ($id === null) {
            throw new PageNotFoundException('Student ID not provided');
        }

        $student = $this->studentModel->find($id);
        if (!$student) {
            throw new PageNotFoundException('Student not found');
        }

        $attendance = $this->attendanceModel->where('student_id', $id)
                                           ->orderBy('date', 'DESC')
                                           ->findAll();

        $data = [
            'title' => 'Student Details',
            'student' => $student,
            'attendance' => $attendance
        ];

        return view('students/show', $data);
    }

    public function attendance($id = null)
    {
        if ($id === null) {
            throw new PageNotFoundException('Student ID not provided');
        }

        $student = $this->studentModel->find($id);
        if (!$student) {
            throw new PageNotFoundException('Student not found');
        }

        $data = [
            'title' => 'Record Attendance',
            'student' => $student
        ];

        return view('students/attendance', $data);
    }

    public function recordAttendance()
    {
        // Validate input
        $rules = [
            'student_id' => 'required|numeric',
            'date' => 'required|valid_date',
            'status' => 'required|in_list[present,absent,late]'
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $studentId = $this->request->getPost('student_id');
        $date = $this->request->getPost('date');
        $status = $this->request->getPost('status');

        // Check if record already exists for this date and student
        $existingRecord = $this->attendanceModel->where('student_id', $studentId)
                                              ->where('date', $date)
                                              ->first();

        if ($existingRecord) {
            // Update existing record
            $this->attendanceModel->update($existingRecord['id'], [
                'status' => $status
            ]);
            session()->setFlashdata('success', 'Attendance record updated.');
        } else {
            // Add new record
            $this->attendanceModel->save([
                'student_id' => $studentId,
                'date' => $date,
                'status' => $status
            ]);
            session()->setFlashdata('success', 'Attendance recorded successfully.');
        }

        return redirect()->to('/students/show/' . $studentId);
    }
}