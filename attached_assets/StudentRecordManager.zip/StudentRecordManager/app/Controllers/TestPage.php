<?php

namespace App\Controllers;

class TestPage extends BaseController
{
    public function index()
    {
        return view('test_page');
    }
}