<?= $this->include('templates/header') ?>

<div class="row mb-4">
    <div class="col-md-6">
        <h1><i class="fas fa-users"></i> Students</h1>
    </div>
    <div class="col-md-6 text-end">
        <a href="<?= site_url('students/new') ?>" class="btn btn-primary">
            <i class="fas fa-plus-circle"></i> Add New Student
        </a>
    </div>
</div>

<div class="card">
    <div class="card-header bg-primary text-white">
        <h5 class="card-title mb-0"><i class="fas fa-list"></i> Student List</h5>
    </div>
    <div class="card-body">
        <?php if (empty($students)): ?>
            <div class="alert alert-info">
                <i class="fas fa-info-circle"></i> No students found. Please add a new student.
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-striped table-hover">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Age</th>
                            <th>Course</th>
                            <th>Grade</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($students as $student): ?>
                            <tr>
                                <td><?= esc($student['id']) ?></td>
                                <td><?= esc($student['name']) ?></td>
                                <td><?= esc($student['age'] ?? 'N/A') ?></td>
                                <td><?= esc($student['course'] ?? 'N/A') ?></td>
                                <td><?= esc($student['grade'] ?? 'N/A') ?></td>
                                <td>
                                    <a href="<?= site_url('students/show/' . $student['id']) ?>" class="btn btn-sm btn-info" title="View">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    <a href="<?= site_url('students/edit/' . $student['id']) ?>" class="btn btn-sm btn-warning" title="Edit">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <a href="<?= site_url('students/attendance/' . $student['id']) ?>" class="btn btn-sm btn-success" title="Attendance">
                                        <i class="fas fa-clipboard-check"></i>
                                    </a>
                                    <a href="<?= site_url('students/delete/' . $student['id']) ?>" class="btn btn-sm btn-danger" 
                                       onclick="return confirm('Are you sure you want to delete this student?')" title="Delete">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<?= $this->include('templates/footer') ?>