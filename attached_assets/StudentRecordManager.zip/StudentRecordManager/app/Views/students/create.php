<?= $this->include('templates/header') ?>

<div class="row mb-4">
    <div class="col-md-12">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?= site_url('/students') ?>">Students</a></li>
                <li class="breadcrumb-item active" aria-current="page">Add New Student</li>
            </ol>
        </nav>
        <h1><i class="fas fa-user-plus"></i> Add New Student</h1>
    </div>
</div>

<div class="card">
    <div class="card-header bg-primary text-white">
        <h5 class="card-title mb-0"><i class="fas fa-user-plus"></i> Enter Student Details</h5>
    </div>
    <div class="card-body">
        <?php if (session()->has('errors')): ?>
            <div class="alert alert-danger">
                <ul class="mb-0">
                    <?php foreach (session('errors') as $error): ?>
                        <li><?= esc($error) ?></li>
                    <?php endforeach ?>
                </ul>
            </div>
        <?php endif; ?>
        
        <form action="<?= site_url('/students/create') ?>" method="post">
            <?= csrf_field() ?>
            
            <div class="mb-3">
                <label for="name" class="form-label">Student Name <span class="text-danger">*</span></label>
                <input type="text" class="form-control" id="name" name="name" 
                       value="<?= old('name') ?>" required>
            </div>
            
            <div class="mb-3">
                <label for="age" class="form-label">Age</label>
                <input type="number" class="form-control" id="age" name="age" 
                       value="<?= old('age') ?>" min="1" max="99">
            </div>
            
            <div class="mb-3">
                <label for="course" class="form-label">Course</label>
                <input type="text" class="form-control" id="course" name="course" 
                       value="<?= old('course') ?>">
            </div>
            
            <div class="mb-3">
                <label for="grade" class="form-label">Grade</label>
                <select class="form-select" id="grade" name="grade">
                    <option value="">Select a grade</option>
                    <option value="A" <?= old('grade') == 'A' ? 'selected' : '' ?>>A</option>
                    <option value="B" <?= old('grade') == 'B' ? 'selected' : '' ?>>B</option>
                    <option value="C" <?= old('grade') == 'C' ? 'selected' : '' ?>>C</option>
                    <option value="D" <?= old('grade') == 'D' ? 'selected' : '' ?>>D</option>
                    <option value="F" <?= old('grade') == 'F' ? 'selected' : '' ?>>F</option>
                </select>
            </div>
            
            <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                <a href="<?= site_url('/students') ?>" class="btn btn-secondary me-md-2">
                    <i class="fas fa-arrow-left"></i> Cancel
                </a>
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save"></i> Save Student
                </button>
            </div>
        </form>
    </div>
</div>

<?= $this->include('templates/footer') ?>