<?= $this->include('templates/header') ?>

<div class="row mb-4">
    <div class="col-md-12">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?= site_url('/students') ?>">Students</a></li>
                <li class="breadcrumb-item"><a href="<?= site_url('/students/show/' . $student['id']) ?>"><?= esc($student['name']) ?></a></li>
                <li class="breadcrumb-item active" aria-current="page">Record Attendance</li>
            </ol>
        </nav>
        <h1><i class="fas fa-clipboard-check"></i> Record Attendance</h1>
    </div>
</div>

<div class="card">
    <div class="card-header bg-primary text-white">
        <h5 class="card-title mb-0"><i class="fas fa-user-check"></i> Record Attendance for <?= esc($student['name']) ?></h5>
    </div>
    <div class="card-body">
        <?php if (session()->has('errors')): ?>
            <div class="alert alert-danger">
                <ul class="mb-0">
                    <?php foreach (session('errors') as $error): ?>
                        <li><?= esc($error) ?></li>
                    <?php endforeach ?>
                </ul>
            </div>
        <?php endif; ?>
        
        <form action="<?= site_url('/students/record-attendance') ?>" method="post">
            <?= csrf_field() ?>
            
            <input type="hidden" name="student_id" value="<?= $student['id'] ?>">
            
            <div class="mb-3">
                <label for="date" class="form-label">Date <span class="text-danger">*</span></label>
                <input type="date" class="form-control" id="date" name="date" 
                       value="<?= old('date', date('Y-m-d')) ?>" required>
            </div>
            
            <div class="mb-3">
                <label for="status" class="form-label">Status <span class="text-danger">*</span></label>
                <select class="form-select" id="status" name="status" required>
                    <option value="present" <?= old('status') == 'present' ? 'selected' : '' ?>>Present</option>
                    <option value="absent" <?= old('status') == 'absent' ? 'selected' : '' ?>>Absent</option>
                    <option value="late" <?= old('status') == 'late' ? 'selected' : '' ?>>Late</option>
                </select>
            </div>
            
            <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                <a href="<?= site_url('/students/show/' . $student['id']) ?>" class="btn btn-secondary me-md-2">
                    <i class="fas fa-arrow-left"></i> Cancel
                </a>
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save"></i> Record Attendance
                </button>
            </div>
        </form>
    </div>
</div>

<?= $this->include('templates/footer') ?>