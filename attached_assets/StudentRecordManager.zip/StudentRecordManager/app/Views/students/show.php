<?= $this->include('templates/header') ?>

<div class="row mb-4">
    <div class="col-md-12">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?= site_url('/students') ?>">Students</a></li>
                <li class="breadcrumb-item active" aria-current="page">Student Details</li>
            </ol>
        </nav>
        <h1><i class="fas fa-user"></i> Student Details</h1>
    </div>
</div>

<div class="row">
    <div class="col-md-6">
        <div class="card">
            <div class="card-header bg-primary text-white">
                <h5 class="card-title mb-0"><i class="fas fa-info-circle"></i> Student Information</h5>
            </div>
            <div class="card-body">
                <table class="table table-bordered">
                    <tr>
                        <th style="width: 30%">ID</th>
                        <td><?= esc($student['id']) ?></td>
                    </tr>
                    <tr>
                        <th>Name</th>
                        <td><?= esc($student['name']) ?></td>
                    </tr>
                    <tr>
                        <th>Age</th>
                        <td><?= esc($student['age'] ?? 'N/A') ?></td>
                    </tr>
                    <tr>
                        <th>Course</th>
                        <td><?= esc($student['course'] ?? 'N/A') ?></td>
                    </tr>
                    <tr>
                        <th>Grade</th>
                        <td>
                            <?php if (!empty($student['grade'])): ?>
                                <span class="badge bg-<?= getGradeBadgeColor($student['grade']) ?>">
                                    <?= esc($student['grade']) ?>
                                </span>
                            <?php else: ?>
                                <span class="text-muted">N/A</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <th>Created At</th>
                        <td><?= !empty($student['created_at']) ? date('M d, Y h:i A', strtotime($student['created_at'])) : 'N/A' ?></td>
                    </tr>
                </table>
                
                <div class="mt-3 d-flex justify-content-between">
                    <a href="<?= site_url('/students') ?>" class="btn btn-secondary">
                        <i class="fas fa-arrow-left"></i> Back to List
                    </a>
                    <div>
                        <a href="<?= site_url('/students/edit/' . $student['id']) ?>" class="btn btn-warning">
                            <i class="fas fa-edit"></i> Edit
                        </a>
                        <a href="<?= site_url('/students/attendance/' . $student['id']) ?>" class="btn btn-success">
                            <i class="fas fa-clipboard-check"></i> Attendance
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-md-6">
        <div class="card">
            <div class="card-header bg-info text-white">
                <h5 class="card-title mb-0"><i class="fas fa-clipboard-list"></i> Attendance History</h5>
            </div>
            <div class="card-body">
                <?php if (empty($attendance)): ?>
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle"></i> No attendance records found for this student.
                    </div>
                    <a href="<?= site_url('/students/attendance/' . $student['id']) ?>" class="btn btn-primary">
                        <i class="fas fa-plus-circle"></i> Record Attendance
                    </a>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-striped table-hover">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($attendance as $record): ?>
                                    <tr>
                                        <td><?= date('M d, Y', strtotime($record['date'])) ?></td>
                                        <td>
                                            <span class="badge bg-<?= getStatusBadgeColor($record['status']) ?>">
                                                <?= ucfirst(esc($record['status'])) ?>
                                            </span>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?= $this->include('templates/footer') ?>

<?php
// Helper functions
function getGradeBadgeColor($grade) {
    $color = 'secondary';
    switch ($grade) {
        case 'A':
            $color = 'success';
            break;
        case 'B':
            $color = 'info';
            break;
        case 'C':
            $color = 'primary';
            break;
        case 'D':
            $color = 'warning';
            break;
        case 'F':
            $color = 'danger';
            break;
    }
    return $color;
}

function getStatusBadgeColor($status) {
    $color = 'secondary';
    switch ($status) {
        case 'present':
            $color = 'success';
            break;
        case 'absent':
            $color = 'danger';
            break;
        case 'late':
            $color = 'warning';
            break;
    }
    return $color;
}
?>