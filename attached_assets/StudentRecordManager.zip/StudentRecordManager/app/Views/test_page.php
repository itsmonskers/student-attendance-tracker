<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test Page</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <div class="card">
            <div class="card-header bg-primary text-white">
                <h2 class="text-center">Student Management System</h2>
            </div>
            <div class="card-body">
                <h3 class="text-center mb-4">Test Page</h3>
                <p class="text-center">If you can see this page, the system is working correctly!</p>
                
                <div class="d-flex justify-content-center mt-4">
                    <a href="/students" class="btn btn-primary me-2">View Students</a>
                    <a href="/attendance" class="btn btn-success">View Attendance</a>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>