<?= $this->include('templates/header') ?>

<div class="row mb-4">
    <div class="col-md-12">
        <h1><i class="fas fa-clipboard-check"></i> Daily Attendance</h1>
    </div>
</div>

<div class="card">
    <div class="card-header bg-primary text-white">
        <h5 class="card-title mb-0"><i class="fas fa-calendar-day"></i> Record Daily Attendance</h5>
    </div>
    <div class="card-body">
        <?php if (session()->has('error')): ?>
            <div class="alert alert-danger">
                <?= session('error') ?>
            </div>
        <?php endif; ?>
        
        <form action="<?= site_url('/attendance/daily') ?>" method="get" class="mb-4">
            <div class="row g-3 align-items-center">
                <div class="col-auto">
                    <label for="date" class="col-form-label">Select Date:</label>
                </div>
                <div class="col-auto">
                    <input type="date" class="form-control" id="date" name="date" value="<?= $date ?>">
                </div>
                <div class="col-auto">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-filter"></i> Filter
                    </button>
                </div>
            </div>
        </form>
        
        <h4 class="mb-3">Attendance for <?= date('F d, Y', strtotime($date)) ?></h4>
        
        <?php if (empty($students)): ?>
            <div class="alert alert-info">
                <i class="fas fa-info-circle"></i> No students found in the system. Please add students first.
            </div>
        <?php else: ?>
            <form action="<?= site_url('/attendance/save') ?>" method="post">
                <?= csrf_field() ?>
                <input type="hidden" name="date" value="<?= $date ?>">
                
                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Student Name</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($students as $index => $student): ?>
                                <input type="hidden" name="students[]" value="<?= $student['id'] ?>">
                                <tr>
                                    <td><?= $index + 1 ?></td>
                                    <td><?= esc($student['name']) ?></td>
                                    <td>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" 
                                                name="status[<?= $index ?>]" 
                                                id="present<?= $student['id'] ?>" 
                                                value="present"
                                                <?= (isset($records[$student['id']]) && $records[$student['id']]['status'] == 'present') ? 'checked' : 
                                                    (!isset($records[$student['id']]) ? 'checked' : '') ?>>
                                            <label class="form-check-label" for="present<?= $student['id'] ?>">Present</label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" 
                                                name="status[<?= $index ?>]" 
                                                id="absent<?= $student['id'] ?>" 
                                                value="absent"
                                                <?= (isset($records[$student['id']]) && $records[$student['id']]['status'] == 'absent') ? 'checked' : '' ?>>
                                            <label class="form-check-label" for="absent<?= $student['id'] ?>">Absent</label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" 
                                                name="status[<?= $index ?>]" 
                                                id="late<?= $student['id'] ?>" 
                                                value="late"
                                                <?= (isset($records[$student['id']]) && $records[$student['id']]['status'] == 'late') ? 'checked' : '' ?>>
                                            <label class="form-check-label" for="late<?= $student['id'] ?>">Late</label>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                
                <div class="d-grid gap-2 d-md-flex justify-content-md-end mt-3">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Save Attendance
                    </button>
                </div>
            </form>
        <?php endif; ?>
    </div>
</div>

<?= $this->include('templates/footer') ?>