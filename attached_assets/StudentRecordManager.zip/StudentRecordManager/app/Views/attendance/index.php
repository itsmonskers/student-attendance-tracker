<?= $this->include('templates/header') ?>

<div class="row mb-4">
    <div class="col-md-6">
        <h1><i class="fas fa-clipboard-list"></i> Attendance Records</h1>
    </div>
    <div class="col-md-6 text-end">
        <a href="<?= site_url('attendance/daily') ?>" class="btn btn-primary">
            <i class="fas fa-clipboard-check"></i> Record Daily Attendance
        </a>
    </div>
</div>

<div class="card">
    <div class="card-header bg-primary text-white">
        <h5 class="card-title mb-0"><i class="fas fa-list"></i> All Attendance Records</h5>
    </div>
    <div class="card-body">
        <?php if (empty($attendance)): ?>
            <div class="alert alert-info">
                <i class="fas fa-info-circle"></i> No attendance records found.
            </div>
            <a href="<?= site_url('attendance/daily') ?>" class="btn btn-primary">
                <i class="fas fa-plus-circle"></i> Record New Attendance
            </a>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-striped table-hover">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Student</th>
                            <th>Date</th>
                            <th>Status</th>
                            <th>Recorded</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($attendance as $record): ?>
                            <tr>
                                <td><?= esc($record['id']) ?></td>
                                <td>
                                    <a href="<?= site_url('students/show/' . $record['student_id']) ?>">
                                        <?= esc($record['student_name']) ?>
                                    </a>
                                </td>
                                <td><?= date('M d, Y', strtotime($record['date'])) ?></td>
                                <td>
                                    <span class="badge bg-<?= getStatusBadgeColor($record['status']) ?>">
                                        <?= ucfirst(esc($record['status'])) ?>
                                    </span>
                                </td>
                                <td><?= !empty($record['created_at']) ? date('M d, Y h:i A', strtotime($record['created_at'])) : 'N/A' ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<?= $this->include('templates/footer') ?>

<?php
// Helper function
function getStatusBadgeColor($status) {
    $color = 'secondary';
    switch ($status) {
        case 'present':
            $color = 'success';
            break;
        case 'absent':
            $color = 'danger';
            break;
        case 'late':
            $color = 'warning';
            break;
    }
    return $color;
}
?>