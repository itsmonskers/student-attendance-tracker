<?= $this->include('templates/header') ?>

<div class="row mb-4">
    <div class="col-md-12">
        <h1><i class="fas fa-chart-bar"></i> Attendance Report</h1>
    </div>
</div>

<div class="card">
    <div class="card-header bg-primary text-white">
        <h5 class="card-title mb-0"><i class="fas fa-filter"></i> Filter Options</h5>
    </div>
    <div class="card-body">
        <form action="<?= site_url('/attendance/report') ?>" method="get">
            <div class="row">
                <div class="col-md-4 mb-3">
                    <label for="start_date" class="form-label">Start Date</label>
                    <input type="date" class="form-control" id="start_date" name="start_date" value="<?= $startDate ?>">
                </div>
                <div class="col-md-4 mb-3">
                    <label for="end_date" class="form-label">End Date</label>
                    <input type="date" class="form-control" id="end_date" name="end_date" value="<?= $endDate ?>">
                </div>
                <div class="col-md-4 mb-3">
                    <label for="student_id" class="form-label">Student (Optional)</label>
                    <select class="form-select" id="student_id" name="student_id">
                        <option value="">All Students</option>
                        <?php foreach ($students as $student): ?>
                            <option value="<?= $student['id'] ?>" <?= ($studentId == $student['id']) ? 'selected' : '' ?>>
                                <?= esc($student['name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
            <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-search"></i> Generate Report
                </button>
            </div>
        </form>
    </div>
</div>

<div class="card mt-4">
    <div class="card-header bg-info text-white">
        <h5 class="card-title mb-0">
            <i class="fas fa-table"></i> 
            Attendance Report 
            <?= $studentId ? ' for ' . esc(getStudentName($students, $studentId)) : '' ?> 
            (<?= date('M d, Y', strtotime($startDate)) ?> - <?= date('M d, Y', strtotime($endDate)) ?>)
        </h5>
    </div>
    <div class="card-body">
        <?php if (empty($report)): ?>
            <div class="alert alert-info">
                <i class="fas fa-info-circle"></i> No attendance records found for the selected criteria.
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-striped table-hover">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Student</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($report as $record): ?>
                            <tr>
                                <td><?= date('M d, Y', strtotime($record['date'])) ?></td>
                                <td>
                                    <a href="<?= site_url('students/show/' . $record['student_id']) ?>">
                                        <?= esc($record['student_name']) ?>
                                    </a>
                                </td>
                                <td>
                                    <span class="badge bg-<?= getStatusBadgeColor($record['status']) ?>">
                                        <?= ucfirst(esc($record['status'])) ?>
                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            
            <div class="row mt-4">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header bg-secondary text-white">
                            <h5 class="card-title mb-0"><i class="fas fa-chart-pie"></i> Summary</h5>
                        </div>
                        <div class="card-body">
                            <?php 
                            $total = count($report);
                            $present = count(array_filter($report, function($r) { return $r['status'] === 'present'; }));
                            $absent = count(array_filter($report, function($r) { return $r['status'] === 'absent'; }));
                            $late = count(array_filter($report, function($r) { return $r['status'] === 'late'; }));
                            
                            $presentPercent = $total > 0 ? round(($present / $total) * 100) : 0;
                            $absentPercent = $total > 0 ? round(($absent / $total) * 100) : 0;
                            $latePercent = $total > 0 ? round(($late / $total) * 100) : 0;
                            ?>
                            
                            <div class="row text-center">
                                <div class="col-md-4">
                                    <div class="card bg-success text-white">
                                        <div class="card-body">
                                            <h5>Present</h5>
                                            <h3><?= $present ?></h3>
                                            <p><?= $presentPercent ?>%</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="card bg-danger text-white">
                                        <div class="card-body">
                                            <h5>Absent</h5>
                                            <h3><?= $absent ?></h3>
                                            <p><?= $absentPercent ?>%</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="card bg-warning text-white">
                                        <div class="card-body">
                                            <h5>Late</h5>
                                            <h3><?= $late ?></h3>
                                            <p><?= $latePercent ?>%</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<?= $this->include('templates/footer') ?>

<?php
// Helper functions
function getStatusBadgeColor($status) {
    $color = 'secondary';
    switch ($status) {
        case 'present':
            $color = 'success';
            break;
        case 'absent':
            $color = 'danger';
            break;
        case 'late':
            $color = 'warning';
            break;
    }
    return $color;
}

function getStudentName($students, $studentId) {
    foreach ($students as $student) {
        if ($student['id'] == $studentId) {
            return $student['name'];
        }
    }
    return 'Unknown Student';
}
?>