<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'TestPage::index');

// Student routes
$routes->get('/students', 'Students::index');
$routes->get('/students/new', 'Students::new');
$routes->post('/students/create', 'Students::create');
$routes->get('/students/edit/(:num)', 'Students::edit/$1');
$routes->post('/students/update/(:num)', 'Students::update/$1');
$routes->get('/students/delete/(:num)', 'Students::delete/$1');
$routes->get('/students/show/(:num)', 'Students::show/$1');
$routes->get('/students/attendance/(:num)', 'Students::attendance/$1');
$routes->post('/students/record-attendance', 'Students::recordAttendance');

// Attendance routes
$routes->get('/attendance', 'Attendance::index');
$routes->get('/attendance/daily', 'Attendance::daily');
$routes->post('/attendance/save', 'Attendance::save');
$routes->get('/attendance/report', 'Attendance::report');