<?php

/**
 * Helper function to get the badge color for the attendance status
 *
 * @param string $status Attendance status (present, absent, late)
 * @return string CSS class for the badge
 */
function getStatusBadgeColor($status)
{
    switch($status) {
        case 'present':
            return 'bg-success';
        case 'absent':
            return 'bg-danger';
        case 'late':
            return 'bg-warning';
        default:
            return 'bg-secondary';
    }
}

/**
 * Helper function to get the badge color for student grade
 *
 * @param string $grade Student grade (A-F)
 * @return string CSS class for the badge
 */
function getGradeBadgeColor($grade)
{
    switch(strtoupper($grade)) {
        case 'A':
            return 'bg-success';
        case 'B':
            return 'bg-primary';
        case 'C':
            return 'bg-info';
        case 'D':
            return 'bg-warning';
        case 'F':
            return 'bg-danger';
        default:
            return 'bg-secondary';
    }
}

/**
 * Helper function to get student name by ID
 *
 * @param array $students Array of students
 * @param int $studentId Student ID
 * @return string Student name or 'Unknown'
 */
function getStudentName($students, $studentId)
{
    foreach ($students as $student) {
        if ($student['id'] == $studentId) {
            return $student['name'];
        }
    }
    return 'Unknown';
}