<?php

namespace App\Models;

use CodeIgniter\Model;

class AttendanceModel extends Model
{
    protected $table = 'attendance';
    protected $primaryKey = 'id';
    
    protected $useAutoIncrement = true;
    protected $returnType = 'array';
    
    protected $allowedFields = ['student_id', 'date', 'status', 'created_at', 'updated_at'];
    
    // Dates
    protected $useTimestamps = true;
    protected $dateFormat = 'datetime';
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';
    
    // Validation
    protected $validationRules = [
        'student_id' => 'required|numeric|is_not_unique[students.id]',
        'date' => 'required|valid_date',
        'status' => 'required|in_list[present,absent,late]'
    ];
    
    protected $validationMessages = [
        'student_id' => [
            'required' => 'Student ID is required',
            'numeric' => 'Student ID must be a number',
            'is_not_unique' => 'The selected student does not exist'
        ],
        'date' => [
            'required' => 'Date is required',
            'valid_date' => 'Please provide a valid date'
        ],
        'status' => [
            'required' => 'Status is required',
            'in_list' => 'Status must be present, absent, or late'
        ]
    ];
    
    protected $skipValidation = false;
}