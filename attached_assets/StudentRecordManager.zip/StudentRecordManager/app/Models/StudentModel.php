<?php

namespace App\Models;

use CodeIgniter\Model;

class StudentModel extends Model
{
    protected $table = 'students';
    protected $primaryKey = 'id';
    
    protected $useAutoIncrement = true;
    protected $returnType = 'array';
    
    protected $allowedFields = ['name', 'age', 'course', 'grade', 'created_at', 'updated_at'];
    
    // Dates
    protected $useTimestamps = true;
    protected $dateFormat = 'datetime';
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';
    
    // Validation
    protected $validationRules = [
        'name' => 'required|min_length[3]|max_length[100]',
        'age' => 'permit_empty|numeric|greater_than[0]|less_than[100]',
        'course' => 'permit_empty|min_length[2]|max_length[100]',
        'grade' => 'permit_empty|alpha|max_length[1]'
    ];
    
    protected $validationMessages = [
        'name' => [
            'required' => 'Student name is required',
            'min_length' => 'Student name must be at least 3 characters long',
            'max_length' => 'Student name cannot exceed 100 characters'
        ],
        'age' => [
            'numeric' => 'Age must be a number',
            'greater_than' => 'Age must be greater than 0',
            'less_than' => 'Age must be less than 100'
        ],
        'course' => [
            'min_length' => 'Course name must be at least 2 characters long',
            'max_length' => 'Course name cannot exceed 100 characters'
        ],
        'grade' => [
            'alpha' => 'Grade must be a letter',
            'max_length' => 'Grade must be a single letter'
        ]
    ];
    
    protected $skipValidation = false;
}